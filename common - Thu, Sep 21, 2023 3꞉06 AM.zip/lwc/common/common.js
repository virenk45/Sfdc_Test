export function getEmployeeColumns() {
    //Build columns
    var employeeColumns = [
        { label: 'CreditorName', fieldName: 'creditorName' },
        { label: 'First Name', fieldName: 'firstName' },
        { label: 'Last Name', fieldName: 'lastName' },
        { label: 'MinPaymentPercentage', fieldName: 'minPaymentPercentage', type: 'percent',
        typeAttributes: {
            step: '0.00001',
            minimumFractionDigits: '2',
            maximumFractionDigits: '3',
        }
        },
        { label: 'Balance', fieldName: 'balance', type: 'currency',
        typeAttributes: { currencyCode: 'USD' } }
    ];
    return employeeColumns;
}