import { LightningElement } from 'lwc';
import { getEmployeeColumns }  from 'c/common';
import getBankDetails from '@salesforce/apex/BankDetailHandler.getBankDetails';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class Tem_detailContainer extends LightningElement {

    employeeColumns = [] ;
    bankData  = [];
    showAddBank = false;
    checkedRecordCount = 0;
    sumOfBalance = 0;
    currentRecordCount;

    //Variable to store initial values
    bankBankDetails={creditorName:'',firstName:'', lastName:'', minPaymentPercentage:'',balance:''}
    
    connectedCallback() {
        //Get columns
        this.employeeColumns = getEmployeeColumns();
        //fetch the data for Bank
        this.fetchBankDetails();
    }

    //Used to fetch the data from API Call and Update the table for the same
    fetchBankDetails() {
        let tempBank = [];
        //Do apex call to get bank details
        getBankDetails().then((eachBank)=>{
            try{
                let data = JSON.parse(eachBank);

                if(data) {
                    for(var i =1; i < data.length; i++) {
                        data[i].Id = i;
                        tempBank.push(data[i]);
                    }
                }
                //Set the data to render the table
                this.bankData = tempBank;
                //Update record count
                this.currentRecordCount = this.bankData.length;
                //Update Total Balance on UI
                this.calculateTotalAmount();
            }catch(error) {
                this.showToast('Error', JSON.stringify(error), 'error', 'dismissable');
            }
            
        })
    }

    //Help to calculate the total amount from the existing records.
    calculateTotalAmount() {
        this.sumOfBalance = 0;
        this.bankData.forEach((eachRec)=>{
            if(eachRec.balance) {
                this.sumOfBalance = this.sumOfBalance + Number(eachRec.balance);
            }
        })
    }

    //Open the pop up after Add Debt button click
    addDept() {
        this.showAddBank = true;
    }

    //Close the pop up after Cancel
    handleCancel() {
        this.showAddBank = false;
    }

    //Build new record from change of each field after Add Debt
    handleChange(event) {
        this.bankBankDetails[event.target.name] = event.target.value;
    }

    //Help to save the data to table and update the Add Debt screen back to default
    handleAdd() {
        this.showAddBank = false;
        this.bankData = [...this.bankData, this.bankBankDetails];
        this.currentRecordCount = this.bankData.length;
        this.calculateTotalAmount();
        this.bankBankDetails = {};
        this.showToast('Success', 'Bank Details has been added successfully!', 'success', 'dismissable');
    }

    //Hanlde selected rows and update the count
    selectedRowHandler(event) {
        const selectedRows = event.detail.selectedRows;
        this.checkedRecordCount = selectedRows.length;
    }

    // This method used to handle removal of selected records from the data table
    removeDept() {
        //get selected records
        let selectedRows = this.template.querySelector('lightning-datatable').selectedRows;
        //filter the selected data
        let bankDetails = this.bankData.filter(eachBank=> 
        selectedRows.every(eachRow=>
            Number(eachRow) != Number(eachBank.Id)
        ));
        //Update and calculate the details for the updated table
        this.bankData = bankDetails;
        this.calculateTotalAmount();
        this.currentRecordCount = this.bankData.length;
        this.showToast('Success', 'Bank Details has been removed successfully!', 'success', 'dismissable');
    }

    showToast(title, message, variant, mode) {
        const event = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
            mode: mode
        });
        this.dispatchEvent(event);
    }
}